lst=[3,6,9,5,12]

for i in lst:
    if(i==5):
        break
    print(i)