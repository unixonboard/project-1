import math

r=float(input("Enter the radius"))
area=math.pi*r**2
print(area)