'''def add(a,b):
    return a+b

print(add(10,20))'''

l=lambda a,b:a+b
print(l(10,20))
