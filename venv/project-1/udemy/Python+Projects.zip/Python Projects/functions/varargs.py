import math
def add(*x):
    print("Sum is"+math.fsum(x))
    
print(add(20,30))