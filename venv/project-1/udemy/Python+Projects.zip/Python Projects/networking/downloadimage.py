import urllib.request

urllib.request.urlretrieve("https://www.python.org/static/img/python-logo@2x.png", "python.png")