a=b=c=10
print(a,b,c)

x,y=10,5

x+=y
print(x)
x*=y
print(x)