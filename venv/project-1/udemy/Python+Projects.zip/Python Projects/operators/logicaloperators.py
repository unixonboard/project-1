x=20
y=30

print((x==25 and y==30))

print((x==25 or y==31))

print(not(x==25 or y==31))